#include <iostream>
#include <vector>
#include <algorithm>
#include "Utils.h"
#include <CImg.h>

void print_help() {
	std::cerr << "Application usage:" << std::endl;

	std::cerr << "  -p : select platform " << std::endl;
	std::cerr << "  -d : select device" << std::endl;
	std::cerr << "  -l : list all platforms and devices" << std::endl;
	std::cerr << "  -h : print this message" << std::endl;
}

//To develop this implementation the Tutorial 3 Project from the provided libraries in the workshops has been used as a foundation and the histogram kernel (hist_simple) and scan_add cumulative histogram kernel have been 
//adapted from the kernels in the original Tutorial 3 library. The main body of the code sets up the devices and all of the data required to call the kernels on device memory. It then
//calls the kernels in order using image data provided in line 60-61 which is initialised on line 82. The first kernel called is the histogram which creates multiple histograms using 
//local memory which are then recombined using atomic operations as the speed of the kernel is faster when using atomic operations than when without atomic operations using barriers to prevent race conditions. 
//The kernel could likely be optimised without using atomic operations to run faster and more efficiently however for this application atomic operations are suitable even though they operate serially which tends to be slower than non-atomic operations.
//The histogram plots the pixel distribution from the input image, the values in the histogram are between a small range of values meaning the image is low contrast.
//The next kernel is then called using the histogram created in the first kernel which plots the total number of pixels in the image against the value of the pixels (0-255) which is a cumulative histogram of the histogram from the first kernel.
//The cumulative histogram that is produced from the kernel is normalised by comparing the pixel density with total potential pixel density to create new values for each pixel which are stored as a look-up table that is created in the third kernel.
//The look-up table is a simple remapping of the cumulative histogram so the kernel is a simple map function.
//The last kernel that is called is the image remapping kernel, this kernel takes the input image buffer, look-up table buffer and output image buffer as conditions as the kernel compares the pixels in the original image to the look-up table and maps the new image with the increased values from the look-up table.
//The result is displayed by the main body of the code alongside the original which shows the increased contrast from the kernel operations.
//The output of the console shows the values in the histogram, cumulative histogram and look-up table. The execution times of each step are also recorded in the console alongside the memory transfers of each kernel to show the performance of the kernels
//This program can be applied to all .pgm images that have been tested of various sizes. 
//By Stephen Duckling DUC19693973

int main(int argc, char **argv) {
	//Part 1 - handle command line options such as device selection, verbosity, etc.
	int platform_id = 0;
	int device_id = 0;

	for (int i = 1; i < argc; i++)	{
		if ((strcmp(argv[i], "-p") == 0) && (i < (argc - 1))) { platform_id = atoi(argv[++i]); }
		else if ((strcmp(argv[i], "-d") == 0) && (i < (argc - 1))) { device_id = atoi(argv[++i]); }
		else if (strcmp(argv[i], "-l") == 0) { std::cout << ListPlatformsDevices() << std::endl; }
		else if (strcmp(argv[i], "-h") == 0) { print_help(); return 0;}
	}

	//detect any potential exceptions
	try {
		//Part 2 - host operations
		//2.1 Select computing devices
		cl::Context context = GetContext(platform_id, device_id);

		//display the selected device
		std::cout << "Running on " << GetPlatformName(platform_id) << ", " << GetDeviceName(platform_id, device_id) << std::endl;

		//create a queue to which we will push commands for the device
		cl::CommandQueue queue(context, CL_QUEUE_PROFILING_ENABLE);
		//queue.clSetCommandQueueProperty(queue, CL_QUEUE_PROPERTIES, CL_QUEUE_PROFILING_ENABLE, 0);
		//2.2 Load & build the device code
		cl::Program::Sources sources;

		AddSources(sources, "kernels/my_kernels.cl");

		std::string host_filename = "images/test.pgm";
		std::string host_filename2 = "images/test_large.pgm";

		cl::Program program(context, sources);

		//build and debug the kernel code
		try {
			program.build();
		}
		catch (const cl::Error& err) {
			std::cout << "Build Status: " << program.getBuildInfo<CL_PROGRAM_BUILD_STATUS>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			std::cout << "Build Options:\t" << program.getBuildInfo<CL_PROGRAM_BUILD_OPTIONS>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			std::cout << "Build Log:\t " << program.getBuildInfo<CL_PROGRAM_BUILD_LOG>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			throw err;
		}

		typedef int mytype;

		//Part 3 - memory allocation
		//host - input
		// "host_filename" can be changed to apply the kernel to a different image 

		cimg_library::CImg<unsigned char> img_input(host_filename.c_str());
		cimg_library::CImgDisplay display_input(img_input, "Input image");

		std::vector<mytype> H(256, 0);
		size_t hist_size = H.size() * sizeof(mytype);

		std::vector<mytype> CH(256, 0);

		std::vector<mytype> LUT(256, 0);

		//cl_image_format format;
		//format.image_channel_order = CL_RGBA;
		//format.image_channel_data_type = CL_UNSIGNED_INT8;



		//cl_mem img = clCreateImage2D(context(), CL_MEM_READ_ONLY | CL_MEM_USE_HOST_PTR, &format, 720, 480, 0, image_data, NULL);

		//cl_sampler sampler = clCreateSampler(context(), CL_FALSE, CL_ADDRESS_CLAMP_TO_EDGE, CL_FILTER_NEAREST, NULL);
		
		
		//srand(time(0));
		//std::generate(A.begin(), A.end(), rand);
		//for (int i = 0; i < A.size(); i++) {
		//
		//			A[i] = (rand() % 10);
		//		}
		//std::vector<mytype> H(10, 0);
		// 
		// 
		//the following part adjusts the length of the input vector so it can be run for a specific workgroup size
		//if the total input length is divisible by the workgroup size
		//this makes the code more efficient

		
		//size_t element_size = clGetImageInfo(img, CL_IMAGE_ELEMENT_SIZE, 16*sizeof(size_t), (void*)element_size, NULL);

		///int img_width = clGetImageInfo(img, CL_IMAGE_WIDTH, 16* sizeof(int), (void*)img_width, NULL);
		//int img_height = clGetImageInfo(img, CL_IMAGE_HEIGHT, 16 * sizeof(int), (void*)img_height, NULL);
		//const int width = img_width;
		//int global_size = img_width * img_height;
		//size_t global_size[2] = { img_width, img_height };
		//int global_work_size = img_width * img_height;
		//size_t local_size[2] = {img_width/16, img_height/16 };
		//int local_work_size = 40;

		//size_t local_size = element_size * img_height;
		//size_t padding_size = global_size % local_size;
		//const int buffer_size = global_work_size * sizeof(int);
		//if the input vector is not a multiple of the local_size
		//insert additional neutral elements (0 for addition) so that the total will not be affected
		//if (padding_size) {
			//create an extra vector with neutral values
		//	std::vector<int> A_ext(local_size-padding_size, 0);
			//append that extra vector to our input
		//	A.insert(A.end(), A_ext.begin(), A_ext.end());
		//}

		//int ip_matrix[width][img_height];
		//std::vector<std::vector<int>> ip_matrix;
		//ip_matrix.resize(img_height, std::vector<int>(img_width, 0));



		//int* ip_array = new int[global_work_size];
		//int* op_array = new int[global_work_size];

		// Calculating min and max of the image input

		//int m = 0;
		//int min = ip_matrix[0][0];
		//int max = ip_matrix[img_width - 1][img_height - 1];
		//for (int i = 0; i < img_height; i++)
		//{
		//	for (int j = 0; j < img_width; j++)
		//	{
		//		ip_array[m] = ip_matrix[i][j];
		//		if (min > ip_array[m])
		//			min = ip_array[m];
		//		if (max < ip_array[m])
		//			max = ip_array[m];
		//		m++;
		//	}
		//}

		//int* minp = &min;
		//int* maxp = &max;

		//std::cout << "minimum value is:" << min << "\n";
		//std::cout << "maximum value is:" << max << "\n";

		//size_t input_elements = global_work_size;//number of input elements

		size_t local_work_size = 256;
		size_t input_size = img_input.size();
		size_t input_byte_size = input_size*sizeof(mytype);//size in bytes
		size_t nr_groups = input_size / local_work_size;

		//host - output
		//std::vector<mytype> B(input_elements);
		//std::vector<mytype> B(input_elements);
		//size_t output_size = B.size()*sizeof(mytype);//size in bytes
		int nr_bins = H.size();
		int min_value = 0;
		//device - buffers

		//cl_mem ip_buffer = clCreateBuffer(context(), CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, buffer_size, ip_array, NULL);
		//cl_mem op_buffer = clCreateBuffer(context(), CL_MEM_WRITE_ONLY, buffer_size, NULL, NULL);


		cl::Buffer buffer_A(context, CL_MEM_READ_ONLY, input_byte_size);
		cl::Buffer buffer_H(context, CL_MEM_READ_WRITE, hist_size);
		cl::Buffer buffer_CH(context, CL_MEM_READ_WRITE, hist_size);
		cl::Buffer buffer_LUT(context, CL_MEM_READ_WRITE, hist_size);
		cl::Buffer buffer_IMG(context, CL_MEM_READ_WRITE, input_byte_size);


		//Part 4 - device operations

		//4.1 copy array A to and initialise other arrays on device memory
		queue.enqueueWriteBuffer(buffer_A, CL_TRUE, 0, input_size, &img_input.data()[0]);
		//queue.enqueueWriteImage(img, 0,  );
		queue.enqueueFillBuffer(buffer_H, 0, 0, hist_size);//zero B buffer on device memory

		//4.2 Setup and execute all kernels (i.e. device code)
		cl::Kernel kernel_hist = cl::Kernel(program, "hist_simple");

		//clSetKernelArg(kernel_hist(), 0, sizeof(cl_mem), &img);
		//clSetKernelArg(kernel_1(), 0, sizeof(cl_mem), &image);
		kernel_hist.setArg(0, buffer_A);
		kernel_hist.setArg(1, buffer_H);
		//kernel_1.setArg(2, sizeof(mytype), NULL);
		clSetKernelArg(kernel_hist(), 2, local_work_size * sizeof(mytype), NULL);
		//clSetKernelArg(kernel_1(), 3, local_size * sizeof(int), NULL);
		kernel_hist.setArg(3, nr_bins);
		kernel_hist.setArg(4, min_value);
		//kernel_1.setArg(2, cl::Local(local_size*sizeof(mytype)));//local memory size
		//clSetKernelArg(kernel_1(), 5, sizeof(cl_sampler), sampler);

		cl::Event event_1;

		//call all kernels in a sequence
		queue.enqueueNDRangeKernel(kernel_hist, cl::NullRange, cl::NDRange(input_size), cl::NDRange(local_work_size), NULL, &event_1);

		//4.3 Copy the result from device to host
		queue.enqueueReadBuffer(buffer_H, CL_TRUE, 0, hist_size, &H[0]);

		//std::cout << "A = " << A << std::endl;
		std::cout << "H = " << H << std::endl;
		//std::cout << "H = " << H << std::endl;

		queue.enqueueFillBuffer(buffer_CH, 0, 0, hist_size);

		//The second kernel call plots a cumulative histogram of the total pixels in the picture across pixel values 0-255, so by 255, all pixels have been counted
		cl::Kernel kernel_hist_cum = cl::Kernel(program, "hist_cum");
		kernel_hist_cum.setArg(0, buffer_H);
		kernel_hist_cum.setArg(1, buffer_CH);

		cl::Event event_2;

		queue.enqueueNDRangeKernel(kernel_hist_cum, cl::NullRange, cl::NDRange(hist_size), cl::NDRange(local_work_size), NULL, &event_2);
		queue.enqueueReadBuffer(buffer_CH, CL_TRUE, 0, hist_size, &CH[0]);

		std::cout << "CH = " << CH << std::endl;

		queue.enqueueFillBuffer(buffer_LUT, 0, 0, hist_size);
		
		//The third kernel call creates a new histogram that will serve as a look up table of the new pixel vales. It does this by normalising the cumulative histogram, essentially decreasing the value of the pixels to increase the contrast
		cl::Kernel kernel_LUT = cl::Kernel(program, "look_up_table");
		kernel_LUT.setArg(0, buffer_CH);
		kernel_LUT.setArg(1, buffer_LUT);

		cl::Event event_3;

		

		queue.enqueueNDRangeKernel(kernel_LUT, cl::NullRange, cl::NDRange(hist_size), cl::NDRange(local_work_size), NULL, &event_3);
		queue.enqueueReadBuffer(buffer_LUT, CL_TRUE, 0, hist_size, &LUT[0]);

		std::cout << "LUT = " << LUT << std::endl;

		//The last kernel assigns the new pixel values from the lookup table to the output image, so that the output is of higher contrast than the input
		cl::Kernel kernel_ReProject = cl::Kernel(program, "project_new");
		kernel_ReProject.setArg(0, buffer_A);
		kernel_ReProject.setArg(1, buffer_LUT);
		kernel_ReProject.setArg(2, buffer_IMG);

		

		cl::Event event_4;

		vector<unsigned char> output_buffer(input_size);
		queue.enqueueNDRangeKernel(kernel_ReProject, cl::NullRange, cl::NDRange(input_byte_size), cl::NDRange(local_work_size), NULL, &event_4);
		queue.enqueueReadBuffer(buffer_IMG, CL_TRUE, 0, output_buffer.size(), &output_buffer.data()[0]);

		cout << endl;
		//std::cout << "Histogram = " << H << std::endl;
		std::cout << "Histogram kernel execution time [ns]: " << event_1.getProfilingInfo<CL_PROFILING_COMMAND_END>() - event_1.getProfilingInfo<CL_PROFILING_COMMAND_START>() << std::endl;
		std::cout << GetFullProfilingInfo(event_1, ProfilingResolution::PROF_US) << endl;
		cout << endl;

		//std::cout << "Cumulative Histogram = " << CH << std::endl;
		std::cout << "Cumulative Histogram kernel execution time [ns]: " << event_1.getProfilingInfo<CL_PROFILING_COMMAND_END>() - event_2.getProfilingInfo<CL_PROFILING_COMMAND_START>() << std::endl;
		std::cout << GetFullProfilingInfo(event_2, ProfilingResolution::PROF_US) << endl;
		cout << endl;

		//std::cout << "LUT = " << LUT << std::endl;
		std::cout << "LUT kernel execution time [ns]: " << event_1.getProfilingInfo<CL_PROFILING_COMMAND_END>() - event_3.getProfilingInfo<CL_PROFILING_COMMAND_START>() << std::endl;
		std::cout << GetFullProfilingInfo(event_3, ProfilingResolution::PROF_US) << endl;
		cout << endl;

		std::cout << "Vector kernel execution time [ns]: " << event_1.getProfilingInfo<CL_PROFILING_COMMAND_END>() - event_4.getProfilingInfo<CL_PROFILING_COMMAND_START>() << std::endl;
		std::cout << GetFullProfilingInfo(event_4, ProfilingResolution::PROF_US) << endl;

		cimg_library::CImg<unsigned char> output_image(output_buffer.data(), img_input.width(), img_input.height(), img_input.depth(), img_input.spectrum());
		cimg_library::CImgDisplay disp_output(output_image, "output");

		while (!display_input.is_closed() && !disp_output.is_closed()
			&& !display_input.is_keyESC() && !disp_output.is_keyESC()) {
			display_input.wait(1);
			disp_output.wait(1);
		}


	}
	catch (cl::Error err) {
		std::cerr << "ERROR: " << err.what() << ", " << getErrorString(err.err()) << std::endl;
	}

	return 0;
}